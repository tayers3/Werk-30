export type MuscleGroup = 
  | "full-body"
  | "upper-body" 
  | "lower-body"
  | "core"
  | "cardio";

export type Intensity = "low" | "medium" | "high";

export interface Exercise {
  id: string;
  name: string;
  muscleGroup: MuscleGroup;
  intensity: Intensity;
  duration: number; // in seconds
  description: string;
  instructions: string[];
}

export const exercises: Exercise[] = [
  // Warm-up exercises
  {
    id: "jumping-jacks",
    name: "Jumping Jacks",
    muscleGroup: "cardio",
    intensity: "low",
    duration: 30,
    description: "A classic warm-up exercise to get your heart pumping.",
    instructions: [
      "Stand with feet together and arms at sides",
      "Jump while spreading legs and raising arms overhead",
      "Return to starting position",
      "Repeat continuously"
    ]
  },
  {
    id: "high-knees",
    name: "High Knees",
    muscleGroup: "cardio",
    intensity: "medium",
    duration: 30,
    description: "Run in place while lifting knees high.",
    instructions: [
      "Stand tall with feet hip-width apart",
      "Drive one knee up toward your chest",
      "Quickly switch to the other leg",
      "Pump your arms as you go"
    ]
  },
  {
    id: "arm-circles",
    name: "Arm Circles",
    muscleGroup: "upper-body",
    intensity: "low",
    duration: 30,
    description: "Loosen up your shoulders and arms.",
    instructions: [
      "Extend arms out to the sides",
      "Make small circles forward",
      "Gradually increase circle size",
      "Reverse direction halfway"
    ]
  },

  // Upper body exercises
  {
    id: "push-ups",
    name: "Push-Ups",
    muscleGroup: "upper-body",
    intensity: "medium",
    duration: 45,
    description: "Classic chest and tricep builder.",
    instructions: [
      "Start in plank position with hands shoulder-width apart",
      "Lower your body until chest nearly touches the floor",
      "Push back up to starting position",
      "Keep core engaged throughout"
    ]
  },
  {
    id: "diamond-push-ups",
    name: "Diamond Push-Ups",
    muscleGroup: "upper-body",
    intensity: "high",
    duration: 45,
    description: "Tricep-focused push-up variation.",
    instructions: [
      "Form a diamond shape with your hands",
      "Position hands under your chest",
      "Lower chest to your hands",
      "Push back up explosively"
    ]
  },
  {
    id: "shoulder-taps",
    name: "Shoulder Taps",
    muscleGroup: "upper-body",
    intensity: "medium",
    duration: 30,
    description: "Core stability with shoulder engagement.",
    instructions: [
      "Start in plank position",
      "Lift one hand to tap opposite shoulder",
      "Return hand to floor",
      "Alternate sides while keeping hips stable"
    ]
  },
  {
    id: "tricep-dips",
    name: "Tricep Dips",
    muscleGroup: "upper-body",
    intensity: "medium",
    duration: 45,
    description: "Target your triceps with this classic move.",
    instructions: [
      "Sit on edge of chair or bench",
      "Place hands beside hips, fingers forward",
      "Slide off edge and lower body",
      "Push back up to starting position"
    ]
  },

  // Lower body exercises
  {
    id: "squats",
    name: "Squats",
    muscleGroup: "lower-body",
    intensity: "medium",
    duration: 45,
    description: "The king of lower body exercises.",
    instructions: [
      "Stand with feet shoulder-width apart",
      "Lower your body as if sitting in a chair",
      "Keep chest up and knees over toes",
      "Return to standing position"
    ]
  },
  {
    id: "jump-squats",
    name: "Jump Squats",
    muscleGroup: "lower-body",
    intensity: "high",
    duration: 30,
    description: "Explosive power for your legs.",
    instructions: [
      "Start in squat position",
      "Explode upward into a jump",
      "Land softly and immediately squat again",
      "Maintain proper form throughout"
    ]
  },
  {
    id: "lunges",
    name: "Walking Lunges",
    muscleGroup: "lower-body",
    intensity: "medium",
    duration: 45,
    description: "Great for balance and leg strength.",
    instructions: [
      "Take a big step forward",
      "Lower back knee toward floor",
      "Push off front foot to step forward",
      "Continue alternating legs"
    ]
  },
  {
    id: "glute-bridges",
    name: "Glute Bridges",
    muscleGroup: "lower-body",
    intensity: "low",
    duration: 45,
    description: "Strengthen your glutes and hamstrings.",
    instructions: [
      "Lie on back with knees bent",
      "Press feet into floor",
      "Lift hips toward ceiling",
      "Squeeze glutes at the top"
    ]
  },
  {
    id: "calf-raises",
    name: "Calf Raises",
    muscleGroup: "lower-body",
    intensity: "low",
    duration: 30,
    description: "Build strong, defined calves.",
    instructions: [
      "Stand on edge of step or flat ground",
      "Rise up onto your toes",
      "Hold briefly at the top",
      "Lower heels back down slowly"
    ]
  },

  // Core exercises
  {
    id: "plank",
    name: "Plank Hold",
    muscleGroup: "core",
    intensity: "medium",
    duration: 45,
    description: "The ultimate core stabilizer.",
    instructions: [
      "Start in push-up position on forearms",
      "Keep body in straight line",
      "Engage core and squeeze glutes",
      "Hold position without sagging"
    ]
  },
  {
    id: "mountain-climbers",
    name: "Mountain Climbers",
    muscleGroup: "core",
    intensity: "high",
    duration: 30,
    description: "Cardio meets core strength.",
    instructions: [
      "Start in plank position",
      "Drive one knee toward chest",
      "Quickly switch legs",
      "Keep hips low and move fast"
    ]
  },
  {
    id: "bicycle-crunches",
    name: "Bicycle Crunches",
    muscleGroup: "core",
    intensity: "medium",
    duration: 45,
    description: "Target your obliques.",
    instructions: [
      "Lie on back with hands behind head",
      "Lift shoulders off ground",
      "Twist elbow to opposite knee",
      "Alternate sides in cycling motion"
    ]
  },
  {
    id: "leg-raises",
    name: "Leg Raises",
    muscleGroup: "core",
    intensity: "medium",
    duration: 45,
    description: "Lower abs focused exercise.",
    instructions: [
      "Lie flat on your back",
      "Keep legs straight and together",
      "Lift legs to 90 degrees",
      "Lower slowly without touching floor"
    ]
  },
  {
    id: "russian-twists",
    name: "Russian Twists",
    muscleGroup: "core",
    intensity: "medium",
    duration: 45,
    description: "Rotational core strength.",
    instructions: [
      "Sit with knees bent, lean back slightly",
      "Lift feet off ground for challenge",
      "Twist torso side to side",
      "Keep core engaged throughout"
    ]
  },

  // Full body / Cardio
  {
    id: "burpees",
    name: "Burpees",
    muscleGroup: "full-body",
    intensity: "high",
    duration: 45,
    description: "The ultimate full-body exercise.",
    instructions: [
      "Start standing, then squat down",
      "Jump feet back to plank",
      "Perform a push-up",
      "Jump feet forward and leap up"
    ]
  },
  {
    id: "squat-thrusts",
    name: "Squat Thrusts",
    muscleGroup: "full-body",
    intensity: "high",
    duration: 30,
    description: "Burpee without the push-up or jump.",
    instructions: [
      "Start standing",
      "Drop into squat, hands on floor",
      "Jump feet back to plank",
      "Jump feet forward, stand up"
    ]
  },
  {
    id: "star-jumps",
    name: "Star Jumps",
    muscleGroup: "cardio",
    intensity: "high",
    duration: 30,
    description: "Explosive full-body cardio.",
    instructions: [
      "Start in squat position",
      "Explode upward",
      "Spread arms and legs into star",
      "Land softly and repeat"
    ]
  },
  {
    id: "butt-kicks",
    name: "Butt Kicks",
    muscleGroup: "cardio",
    intensity: "medium",
    duration: 30,
    description: "Run in place kicking heels to glutes.",
    instructions: [
      "Stand tall",
      "Jog in place",
      "Kick heels up toward glutes",
      "Pump arms naturally"
    ]
  },
  {
    id: "skaters",
    name: "Skaters",
    muscleGroup: "full-body",
    intensity: "medium",
    duration: 45,
    description: "Lateral movement for agility.",
    instructions: [
      "Stand on one leg",
      "Leap sideways to other leg",
      "Swing arms for momentum",
      "Land softly and repeat"
    ]
  },
];

export function getExercisesByMuscleGroup(muscleGroup: MuscleGroup): Exercise[] {
  return exercises.filter(e => e.muscleGroup === muscleGroup);
}

export function getExercisesByIntensity(intensity: Intensity): Exercise[] {
  return exercises.filter(e => e.intensity === intensity);
}

export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  if (mins === 0) return `${secs}s`;
  return secs === 0 ? `${mins}m` : `${mins}m ${secs}s`;
}

export function formatTotalTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
